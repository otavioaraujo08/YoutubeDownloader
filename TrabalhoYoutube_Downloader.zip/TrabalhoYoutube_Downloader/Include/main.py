import os
import pytube
from pytube import YouTube
from pytube import Playlist

def downloadURL(url):
    youtube = pytube.YouTube(url)

    #Exibir a lista de formatos disponíveis.
    i = 1
    for lista in youtube.streams.order_by('resolution'):
        try:
            print(lista)
            i += 1
        except:
            pass
    video = youtube.streams.filter(progressive=True, file_extension="mp4").order_by("resolution").last()

    #Título do Vídeo
    title = video.title
    print(f"Iniciando Download: {str(title)} ")

    #Path do Download
    video.download(os.getcwd() + '/Include/YoutubeVideoDownload')

def downloadPlaylist(url_playlist):
    pl = Playlist(url_playlist)
    i = 1
    print("Iniciando download da Playlist.")
    for video in pl.videos:
        video.streams.filter(progressive=True, file_extension="mp4").order_by("resolution").get_highest_resolution().download(os.getcwd() + '/Include/YoutubePlaylist')
        try:
             #Título do Vídeo
            title = video.title
            print(f"Iniciando Download: {str(i)}:  {str(title)} ")
        except:
            print('DEU ERRO POLINELSOM')


#downloadURL("")
downloadPlaylist(
    "https://www.youtube.com/playlist?list=PLP4ZOYXEvXutNOdKhk7ubJoMqU3WZaboR")
